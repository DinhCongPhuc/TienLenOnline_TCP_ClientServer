package server;
// File: TienLenServer.java
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import com.google.gson.*; // thêm gson vào classpath

public class TienLenServer {
    private static final int PORT = 12345;
    private ServerSocket serverSocket;
    private Map<String, Player> players = new ConcurrentHashMap<>();
    private Map<String, Room> rooms = new ConcurrentHashMap<>();
    private ExecutorService exec = Executors.newCachedThreadPool();
    private Gson gson = new Gson();

    public static void main(String[] args) throws Exception {
        new TienLenServer().start();
    }

    public void start() throws Exception {
        serverSocket = new ServerSocket(PORT);
        System.out.println("Server listening on " + PORT);
        while (true) {
            Socket sock = serverSocket.accept();
            exec.submit(() -> handleClient(sock));
        }
    }

    private void handleClient(Socket sock) {
        try (Socket s = sock;
             BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
             PrintWriter out = new PrintWriter(s.getOutputStream(), true)) {

            String clientId = UUID.randomUUID().toString();
            Player me = new Player(clientId, null, s, in, out);
            players.put(clientId, me);

            String line;
            while ((line = in.readLine()) != null) {
                JsonObject msg = gson.fromJson(line, JsonObject.class);
                String type = msg.get("type").getAsString();
                JsonObject payload = msg.has("payload") ? msg.get("payload").getAsJsonObject() : new JsonObject();

                switch (type) {
                    case "LOGIN":
                        String name = payload.get("name").getAsString();
                        me.name = name;
                        send(out, "LOGIN_OK", JsonNull.INSTANCE);
                        break;
                    case "CREATE_ROOM":
                        String roomId = "room-" + UUID.randomUUID().toString().substring(0,6);
                        Room r = new Room(roomId, payload.get("roomName").getAsString());
                        r.addPlayer(me);
                        rooms.put(roomId, r);
                        send(out, "ROOM_CREATED", gson.toJsonTree(Map.of("roomId", roomId)));
                        broadcastRoomUpdate(r);
                        break;
                    case "JOIN_ROOM":
                        String rid = payload.get("roomId").getAsString();
                        Room room = rooms.get(rid);
                        if (room == null) { send(out, "ERROR", gson.toJsonTree(Map.of("message","Room not found"))); break;}
                        room.addPlayer(me);
                        broadcastRoomUpdate(room);
                        break;
                    case "READY":
                        Room rr = findPlayerRoom(me);
                        if (rr != null) {
                            me.ready = true;
                            broadcastRoomUpdate(rr);
                            if (rr.allReadyAndFull()) {
                                rr.startGame();
                            }
                        }
                        break;
                    case "PLAY_CARDS":
                        Room rplay = findPlayerRoom(me);
                        if (rplay != null && rplay.game != null) {
                            JsonArray arr = payload.get("cards").getAsJsonArray();
                            List<String> cards = new ArrayList<>();
                            arr.forEach(e -> cards.add(e.getAsString()));
                            rplay.game.processPlay(me, cards);
                        }
                        break;
                    case "PASS":
                        Room rpass = findPlayerRoom(me);
                        if (rpass != null && rpass.game != null) {
                            rpass.game.processPass(me);
                        }
                        break;
                    case "CHAT":
                        Room rchat = findPlayerRoom(me);
                        if (rchat != null) {
                            rchat.broadcast("CHAT_BROADCAST", gson.toJsonTree(Map.of("from", me.name, "text", payload.get("text").getAsString())));
                        }
                        break;
                    default:
                        send(out, "ERROR", gson.toJsonTree(Map.of("message","Unknown type " + type)));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // cleanup
            // remove player from rooms
        }
    }

    private void send(PrintWriter out, String type, Object payload) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", type);
        msg.add("payload", gson.toJsonTree(payload));
        out.println(gson.toJson(msg));
    }

    private void broadcastRoomUpdate(Room r) {
        r.broadcast("ROOM_UPDATE", gson.toJsonTree(Map.of(
            "players", r.playerNames(),
            "status", r.state.name()
        )));
    }

    private Room findPlayerRoom(Player p) {
        return rooms.values().stream().filter(r -> r.hasPlayer(p)).findFirst().orElse(null);
    }

    // --- inner classes Player, Room, Game simplified below ---
    class Player {
        String id; String name; Socket sock; BufferedReader in; PrintWriter out;
        List<String> hand = new ArrayList<>();
        boolean ready = false;
        Player(String id, String name, Socket sock, BufferedReader in, PrintWriter out) {
            this.id = id; this.name = name; this.sock = sock; this.in = in; this.out = out;
        }
    }

    class Room {
        String id, name; List<Player> players = Collections.synchronizedList(new ArrayList<>());
        RoomState state = RoomState.WAITING;
        Game game;
        Room(String id, String name) { this.id = id; this.name = name; }
        void addPlayer(Player p) { if (players.size()<4) players.add(p); }
        boolean hasPlayer(Player p) { return players.contains(p); }
        List<String> playerNames() { List<String> l=new ArrayList<>(); for (Player p:players) l.add(p.name); return l; }
        boolean allReadyAndFull() { return players.size()==4 && players.stream().allMatch(pl->pl.ready); }
        void broadcast(String type, JsonElement payload) {
            players.forEach(pl -> pl.out.println(gson.toJson(Map.of("type", type, "payload", payload))));
        }
        void startGame() {
            this.state = RoomState.PLAYING;
            this.game = new Game(this);
            this.game.start();
        }
    }
    enum RoomState { WAITING, PLAYING }

    class Game {
        Room room;
        List<String> deck = new ArrayList<>();
        int currentIdx = 0;
        List<String> lastPlay = null;
        Game(Room room) { this.room = room; }
        void start() {
            initDeck();
            Collections.shuffle(deck);
            // deal 13 each
            for (int i=0;i<4;i++) {
                Player p = room.players.get(i);
                p.hand.clear();
                for (int j=0;j<13;j++) p.hand.add(deck.remove(0));
                // send GAME_START to each
                p.out.println(gson.toJson(Map.of("type","GAME_START","payload", Map.of("yourCards", p.hand, "firstPlayer", room.players.get(0).id))));
            }
            currentIdx = 0;
            broadcastState();
        }
        void initDeck() {
            String[] ranks = {"3","4","5","6","7","8","9","10","J","Q","K","A","2"};
            String[] suits = {"C","D","H","S"};
            deck.clear();
            for (String r: ranks) for (String s: suits) deck.add(r+s);
        }
       void processPlay(Player p, List<String> cards) {
    if (room.players.get(currentIdx) != p) {
        sendPlayResult(p, false, "Không phải lượt của bạn");
        return;
    }
    if (!p.hand.containsAll(cards)) {
        sendPlayResult(p, false, "Bạn không có những lá này");
        return;
    }
    // (chưa kiểm tra luật, demo cho phép mọi bộ)
    p.hand.removeAll(cards);
    lastPlay = new ArrayList<>(cards);

    // gửi thông báo thành công cho chính player đó
    sendPlayResult(p, true, "Đánh thành công");

    // broadcast trạng thái mới cho tất cả
    broadcastState();

    // kiểm tra thắng
    if (p.hand.isEmpty()) {
        room.broadcast("GAME_END", gson.toJsonTree(Map.of("winner", p.name)));
        room.state = RoomState.WAITING;
        room.game = null;
        return;
    }
    currentIdx = (currentIdx+1) % room.players.size();
}

private void sendPlayResult(Player p, boolean success, String message) {
    JsonObject msg = new JsonObject();
    msg.addProperty("type", "PLAY_RESULT");
    JsonObject payload = new JsonObject();
    payload.addProperty("success", success);
    payload.addProperty("message", message);
    msg.add("payload", payload);
    p.out.println(gson.toJson(msg));
}

        void processPass(Player p) {
            if (room.players.get(currentIdx) != p) {
                p.out.println(gson.toJson(Map.of("type","PLAY_RESULT","payload", Map.of("success",false,"message","Not your turn"))));
                return;
            }
            currentIdx = (currentIdx+1)%room.players.size();
            broadcastState();
        }
        void broadcastState() {
            Map<String,Object> payload = new HashMap<>();
            payload.put("currentPlayer", room.players.get(currentIdx).id);
            payload.put("lastPlay", lastPlay);
            Map<String,Integer> sizes = new HashMap<>();
            for (Player pl: room.players) sizes.put(pl.id, pl.hand.size());
            payload.put("handsSizes", sizes);
            room.broadcast("GAME_STATE", gson.toJsonTree(payload));
        }
    }
}
