package client.view;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.google.gson.JsonObject;
import client.*;

public class LoginView {
    private VBox root = new VBox(10);
    private TextField nameField = new TextField();
    private Button loginButton = new Button("Login");

    public LoginView(NetworkClient client, Stage stage) {
        root.setPadding(new Insets(20));
        Label label = new Label("Nhập tên của bạn:");

        root.getChildren().addAll(label, nameField, loginButton);

        loginButton.setOnAction(e -> {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                client.send("LOGIN", new LoginPayload(name));

                client.setOnMessage((JsonObject msg) -> {
                    String type = msg.get("type").getAsString();
                    if (type.equals("LOGIN_OK")) {
                        // Chuyển sang RoomView
                        RoomView rv = new RoomView(client, stage);
                        javafx.application.Platform.runLater(() -> {
                            stage.setScene(new Scene(rv.getRoot(), 600, 400));
                        });
                    }
                });
            }
        });
    }

    public VBox getRoot() { return root; }

    static class LoginPayload {
        String name;
        LoginPayload(String n) { this.name = n; }
    }
}

