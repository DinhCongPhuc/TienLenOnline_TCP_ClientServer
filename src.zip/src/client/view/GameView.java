package client.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import client.*;

import java.util.*;

public class GameView {
    private BorderPane root = new BorderPane();

    private HBox handBox = new HBox(5); // lá bài ngang
    private VBox otherPlayersBox = new VBox(5); // hiển thị người chơi khác
    private Label lastPlayLabel = new Label("Bài vừa đánh: (chưa có)");

    private Button playBtn = new Button("Đánh");
    private Button passBtn = new Button("Bỏ lượt");
    private Button sortBtn = new Button("Xếp bài");

    private NetworkClient client;

    public GameView(NetworkClient client, Stage stage, JsonObject payload) {
        this.client = client;

        handBox.setPadding(new Insets(10));
        handBox.setAlignment(Pos.CENTER);

        // Hiển thị bài của bạn từ GAME_START
        JsonArray cards = payload.get("yourCards").getAsJsonArray();
        for (int i = 0; i < cards.size(); i++) {
            String cardText = cards.get(i).getAsString();
            CheckBox cb = new CheckBox(cardText);
            handBox.getChildren().add(cb);
        }

        // thanh nút bấm
        HBox actions = new HBox(10, playBtn, passBtn, sortBtn);
        actions.setAlignment(Pos.CENTER);
        actions.setPadding(new Insets(10));

        VBox bottom = new VBox(10, handBox, actions);
        bottom.setAlignment(Pos.CENTER);

        // hiển thị người chơi khác + bài vừa đánh ở trên
        otherPlayersBox.setPadding(new Insets(10));
        otherPlayersBox.setAlignment(Pos.CENTER_LEFT);
        VBox top = new VBox(10, otherPlayersBox, lastPlayLabel);
        root.setTop(top);

        root.setBottom(bottom);

        // ====== Xử lý nút bấm ======
        playBtn.setOnAction(e -> {
            List<String> selected = handBox.getChildren().stream()
                .filter(n -> ((CheckBox)n).isSelected())
                .map(n -> ((CheckBox)n).getText())
                .toList();

            if (!selected.isEmpty()) {
                client.send("PLAY_CARDS", new Object(){ java.util.List<String> cards = selected; });
            }
        });

        passBtn.setOnAction(e -> client.send("PASS", new Object()));

        sortBtn.setOnAction(e -> sortHand());

        // ====== Lắng nghe phản hồi từ server ======
        client.setOnMessage((JsonObject msg) -> {
            String type = msg.get("type").getAsString();

            if (type.equals("GAME_STATE")) {
                JsonObject payloadState = msg.getAsJsonObject("payload");
                JsonObject handsSizes = payloadState.getAsJsonObject("handsSizes");
                JsonArray lastPlay = payloadState.getAsJsonArray("lastPlay");
                String currentPlayer = payloadState.get("currentPlayer").getAsString();

                javafx.application.Platform.runLater(() -> {
                    // cập nhật số lá của mỗi player
                    otherPlayersBox.getChildren().clear();
                    handsSizes.entrySet().forEach(entry -> {
                        String pid = entry.getKey();
                        int size = entry.getValue().getAsInt();
                        Label lbl = new Label("Player " + pid + ": còn " + size + " lá"
                                + (pid.equals(currentPlayer) ? "  <-- lượt hiện tại" : ""));
                        otherPlayersBox.getChildren().add(lbl);
                    });

                    // hiển thị bài vừa đánh
                    if (lastPlay != null && lastPlay.size() > 0) {
                        StringBuilder sb = new StringBuilder("Bài vừa đánh: ");
                        for (int i = 0; i < lastPlay.size(); i++) {
                            sb.append(lastPlay.get(i).getAsString()).append(" ");
                        }
                        lastPlayLabel.setText(sb.toString());
                    } else {
                        lastPlayLabel.setText("Bài vừa đánh: (chưa có)");
                    }
                });
            }
            else if (type.equals("PLAY_RESULT")) {
                JsonObject payloadRes = msg.getAsJsonObject("payload");
                boolean success = payloadRes.get("success").getAsBoolean();
                String message = payloadRes.get("message").getAsString();

                javafx.application.Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION,
                            success ? "Đánh thành công!" : "Đánh thất bại: " + message);
                    alert.showAndWait();
                });
            }
        });
    }

    public BorderPane getRoot() { return root; }

    // ====== Hàm xếp bài ======
    private void sortHand() {
        List<CheckBox> cards = handBox.getChildren().stream()
            .map(n -> (CheckBox) n)
            .sorted(Comparator.comparingInt(cb -> rankValue(cb.getText())))
            .toList();

        handBox.getChildren().clear();
        handBox.getChildren().addAll(cards);
    }

    // ====== Hàm tính giá trị lá bài ======
    private int rankValue(String card) {
        // card ví dụ: "3C", "10D", "AS", "2H"
        String rank = card.replaceAll("[CDHS]", ""); // bỏ chất
        String[] order = {"3","4","5","6","7","8","9","10","J","Q","K","A","2"};
        for (int i = 0; i < order.length; i++) {
            if (order[i].equals(rank)) return i;
        }
        return -1;
    }
}
