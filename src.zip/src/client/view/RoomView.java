package client.view;

import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.Scene;

import com.google.gson.JsonObject;
import client.*;

public class RoomView {
    private VBox root = new VBox(10);
    private Button createBtn = new Button("Tạo phòng");
    private TextField roomIdField = new TextField();
    private Button joinBtn = new Button("Tham gia phòng");
    private Button readyBtn = new Button("Sẵn sàng");
    private ListView<String> playerList = new ListView<>();

    public RoomView(NetworkClient client, Stage stage) {
        root.setPadding(new javafx.geometry.Insets(20));
        root.getChildren().addAll(
            new Label("Phòng"),
            createBtn, 
            new Label("Room ID:"), roomIdField, joinBtn, 
            readyBtn,
            new Label("Người chơi trong phòng:"), playerList
        );

        createBtn.setOnAction(e -> {
            client.send("CREATE_ROOM", new CreateRoomPayload("MyRoom"));
        });

        joinBtn.setOnAction(e -> {
            client.send("JOIN_ROOM", new JoinRoomPayload(roomIdField.getText().trim()));
        });

         readyBtn.setOnAction(e -> {
            client.send("READY", new Object());  // 👈 gửi READY
        });

        client.setOnMessage((JsonObject msg) -> {
            String type = msg.get("type").getAsString();

            if (type.equals("ROOM_CREATED")) {
                // lấy roomId từ payload
                String newRoomId = msg.getAsJsonObject("payload").get("roomId").getAsString();
                javafx.application.Platform.runLater(() -> {
                    roomIdField.setText(newRoomId);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Phòng đã tạo, Room ID: " + newRoomId);
                    alert.showAndWait();
                });
            } 
            else if (type.equals("ROOM_UPDATE")) {
                JsonObject payload = msg.getAsJsonObject("payload");
                var arr = payload.getAsJsonArray("players");

                javafx.application.Platform.runLater(() -> {
                    playerList.getItems().clear();
                    for (int i = 0; i < arr.size(); i++) {
                        playerList.getItems().add(arr.get(i).getAsString());
                    }
                });
            } 
            else if (type.equals("GAME_START")) {
                GameView gv = new GameView(client, stage, msg.get("payload").getAsJsonObject());
                javafx.application.Platform.runLater(() -> {
                    stage.setScene(new Scene(gv.getRoot(), 800, 600));
                });
            }
        });
    }

    public VBox getRoot() { return root; }

    static class CreateRoomPayload { 
        String roomName; 
        CreateRoomPayload(String n){ this.roomName=n; } 
    }
    static class JoinRoomPayload { 
        String roomId; 
        JoinRoomPayload(String id){ this.roomId=id; } 
    }
}
