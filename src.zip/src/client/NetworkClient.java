package client;

import java.io.*;
import java.net.*;
import java.util.function.Consumer;
import com.google.gson.*;

public class NetworkClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread listener;
    private Gson gson = new Gson();

    private Consumer<JsonObject> onMessage;

    public NetworkClient(String host, int port) throws IOException {
        socket = new Socket(host, port);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        listener = new Thread(() -> {
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    JsonObject msg = gson.fromJson(line, JsonObject.class);
                    if (onMessage != null) onMessage.accept(msg);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        listener.start();
    }

    public void setOnMessage(Consumer<JsonObject> handler) {
        this.onMessage = handler;
    }

    public void send(String type, Object payload) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", type);
        msg.add("payload", gson.toJsonTree(payload));
        out.println(gson.toJson(msg));
    }

    public void close() throws IOException {
        socket.close();
    }
}

