package client;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import client.view.*;

public class MainApp extends Application {
    private NetworkClient client;

    @Override
    public void start(Stage primaryStage) throws Exception {
        client = new NetworkClient("localhost", 12345);

        LoginView loginView = new LoginView(client, primaryStage);
        Scene scene = new Scene(loginView.getRoot(), 400, 300);

        primaryStage.setTitle("Tiến Lên Online");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        if (client != null) client.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
